
package APSBootScan;

# The purpose of this package is to implement subroutines which
# identify ioc's to be crawled, and their startup command file 
# names and paths. Since this differs from EPICS facility to 
# facility, we need to have one of these packages per facility.
#
# Implements the required "find_boot_iocs" subroutine of the BootScan
# package for the APS facility. This subroutine must return an
# array of hashes, each hash as follows:
#  $boot_info = {ioc_nm=>"$ioc_nm",            # ioc name
#                booted=>"$ioc_booted",        # is it considered booted?
#                boot_date=>"$boot_date",      # date of boot
#                st_cmd_dir=>"$stCmdDir",      # startup command
#                st_cmd_file=>"$stCmdFile"};
#

use File::Basename; 
use File::stat;

use PVCrawlerDBLayer;
use LogUtil;

require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw(find_boot_iocs);
our @EXPORT_OK = qw();
our $VERSION = 1.00;

# Location where site IOC's boot from
my $ioc_boot_base_dir = "/net/helios/iocapps/iocinfo";

#
# Returns array of hashes, one element per ioc. 
#
sub find_boot_iocs {

    my @boot_infos = ();

    if ( ! -d $ioc_boot_base_dir ) {
        # A cron job will send stderr output in mail
        print STDERR "Directory $ioc_boot_base_dir not found.";
        log('error',"Directory $ioc_boot_base_dir not found.";
        return @boot_infos;
    }

    chdir $ioc_boot_base_dir . "/bootparams"; 
    
    my $candidate_ioc_names = PVCrawlerDBLayer::ioc_find();
    my @ioc_names = ();
    
    # put any rules here to filter out unwanted iocs
    foreach $ioc_nm (@$candidate_ioc_names) {
        if ($ioc_nm =~ /^ioc.*/ ||
            $ioc_nm =~ /^sioc.*/) {
            push @ioc_names, "$ioc_nm";
        }
    }

    log('debug',"iocs to be boot scanned: @ioc_names");

    # iterate over set of ioc names
    foreach $ioc_nm (@ioc_names) {
        # collect info about ioc boot 
        my $boot_date = "";
        my $st_cmd_dir = "";
        my $st_cmd_file = "";
        # zero if we consider ioc not booted, or not bootable
        my $ioc_booted = 1;
 
        # Based on how ioc's boot right now, the bootparams dir is
        #  all we can make use of.
        $bootParamPath = $ioc_boot_base_dir . "/bootparams/" . $ioc_nm;

        $bootLine = getBootParamsBootLine($bootParamPath);
        # Consider ioc not booted since we can't read boot line
        if (!$bootLine) {
            log('warn',"unable to read boot line from $bootParamPath");
            $ioc_booted = 0;
        }

        if ($bootLine) {
            $boot_date = stat($bootParamPath)->mtime;
            # the stuff after "s=".  May not always be 'st.cmd'...
            $bootLine =~ /(s=)(\S*)/;
            $stCmdFile = $2;
            # strip any trailing spaces
            if ($stCmdFile =~ /(.*) / ) {
                $stCmdFile = $1;
            }
            # if fully qualified path
            if ($stCmdFile =~ "^/") {
                $stCmdDir = dirname($stCmdFile);
                $stCmdFile = basename($stCmdFile);
                
            } else {
                $stCmdFile = basename($stCmdFile);
                # Looks like we have to figure out dir from other part of boot line
                # Compatible `with 3.13.<1  - the base path to locate st.cmd, 
                #  ../nfs.cmd, cdCommands
                $bootLine =~ m/:(.*)vxWor/;
                $stCmdDir = $1;
            }
            if (!$stCmdDir || !$stCmdFile) {
                log('warn',"unable to determine startup command dir and/or file from $bootParamPath");
                $ioc_booted = 0;
            }            
        }

        # Create new boot_info hash entry
        if ($ioc_booted) {
            $new_boot_info = {ioc_nm=>"$ioc_nm", booted=>"$ioc_booted",
                              boot_date=>"$boot_date", 
                              st_cmd_dir=>"$stCmdDir",  st_cmd_file=>"$stCmdFile"};
        } else {
            $new_boot_info = {ioc_nm=>"$ioc_nm", booted=>"$ioc_booted",
                              boot_date=>"", 
                              st_cmd_dir=>"",  st_cmd_file=>""};
        }

        push @boot_infos, $new_boot_info;
    }

    return @boot_infos;
}


#
# Private subroutine, not exposed by package
#
sub getBootParamsBootLine {

    my $iocBootParamsPath = $_[0]; # ioc name as argument

    if (!open(BOOTPARAMS, $iocBootParamsPath)) {
        log('warn', "cannot open $iocBootParamsPath: $!");
        return;
    }
    # $_ is a single line - from: printf("%s\n",sysBootLine) > 
    #    /home/helios4/iocinfo/bootparams/iocxxx
    $_=<BOOTPARAMS>;
    chomp();
    close(BOOTPARAMS);
    
    return $_;
}

#
# preserving some code, although not sure what this if for yet
#
#  $stCmdFullPath{$ioc} = $stCmdDir{$ioc}.$stCmdFile{$ioc};
#  if ($stCmdFile{$ioc} =~ m"^/" ){      #full path given for st.cmd implies >= 3.13.1
#    $stCmdFullPath{$ioc} = $stCmdFile{$ioc};    #used only to print to journal file
#    $stCmdFullPath{$ioc} =~ m|(/.*/)|;
#    $stCmdDir{$ioc} = $1;        #get everything including the /'s
#  }
#
#  if($stCmdFullPath{$ioc} =~/^\/iocapps/)
#  {
#    print "the base path of $stCmdDir{$ioc}";
#    $stCmdDir{$ioc} = "/usr/local".$stCmdDir{$ioc};
#    print " has been changed to $stCmdDir{$ioc}\n";
#    $modDir  = "/usr/local".$stCmdFullPath{$ioc};
#    print "full stcmd path $stCmdFullPath{$ioc} changed to $modDir\n";
#    $stCmdFullPath{$ioc} = $modDir;
#  }
#

1;
